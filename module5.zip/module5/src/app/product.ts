export class Product
{
public id:number;
public brand_id: number;
public name:string;
 public category: string;
 public description:string
 public price:number;
 public discount:string;
 public quantity: number;
 public conprice: number;
 public charges: number;
 public tax: number;
 public promo: number;
 public finalprice:number;
}











