import { Component, OnInit, Injector, RootRenderer, Injectable } from '@angular/core';
import { ProductServiceService } from '../product-service.service';
import { Product } from '../product';

@Component({
  selector: 'app-show-products',
  templateUrl: './show-products.component.html',
  styleUrls: ['./show-products.component.css']

})
@Injectable({
  providedIn:'root'
})

export class ShowProductsComponent implements OnInit {
   
Product:Product;
  constructor(private productService : ProductServiceService) { }

  ngOnInit() {
    this.showProducts();
  }


  showProducts()
  {
  this.productService.showProducts().subscribe(data=>(this.Product=data));
}
flag=false;
id;brand_id;name;category;description;price;discount;quantity;conprice;charges;tax;promo;finalprice;
b:Product=new Product();
changeFlag(b:Product)
 {
   
  this.flag=true;
  this.id=b.id;
  this.brand_id=b.brand_id;
  this.name=b.name;
  this.category=b.category;
  this.description=b.description;
  this.price=b.price;
  this.discount=b.discount;
  this.quantity=b.quantity;
  this.conprice=b.conprice;
  this.charges=b.charges;
  this.tax=b.tax;
  this.promo=b.promo;
  this.finalprice=b.finalprice;
 }

}

