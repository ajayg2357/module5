import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { Product } from './product';

@Injectable({
  providedIn: 'root'
})
export class ProductServiceService {
  id: number;

  url = 'http://localhost:8054/delete';
  baseUrl='http://localhost:8054/view';

 constructor(private httpClient:HttpClient) { }

 login(uName, pwd): Observable<number> {
  let url = 'http://localhost:9002/login/' + uName + '/' + pwd;

 return this.httpClient.get<number>(url);
}

getid() {
  return this.id;
}

setid(id: number) {
  this.id = id;
}
 
 public showProducts()
 {
 
 return this.httpClient.get<Product>("http://localhost:8054/view" );
 }
 

 
 public createProduct(userDetails) {
   console.log(userDetails);
 return this.httpClient.post<Product>("http://localhost:8054/create", userDetails);
 }

 public updateProduct(): Observable<any>
 {
 
 let url = 'http://localhost:8054/update';
 return this.httpClient.post<Product>(url,'');
 }
 
 public deleteProduct(id:number): Observable<any>
 {
 console.log(id);
 //let url = 'http://localhost:8054/delete/{id}'+id+'/';
 return this.httpClient.delete<void>(`${this.url}/${id}`);
 }

 public showbyid(data1:number) : Observable<Product>
 {
   console.log(data1)
   return this.httpClient.get<Product>(`${this.baseUrl}/${data1}`);
 }




 
 
}

